sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("capfullstack02fiori.capfullstack02fiori.controller.App", {
        onInit() {
        }
      });
    }
  );
  